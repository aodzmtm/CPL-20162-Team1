package org.java_websocket;

import org.junit.runner.RunWith;

import cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
public class AutobahnClientTest {

}
